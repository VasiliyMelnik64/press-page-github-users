import { baseURL } from './constants';

export const defaultConfig = {
  baseURL,
  headers: {
    'Content-Type': 'appllication/json',
  },
};
