export const baseURL = 'https://api.github.com/users';
